package com.example.TicketingSystem.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CommentDto {
    private String comment;
    private String commentedBy;
}
