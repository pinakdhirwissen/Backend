package com.example.TicketingSystem.services;

import com.example.TicketingSystem.models.Attachments;
import com.example.TicketingSystem.models.Tickets;
import com.example.TicketingSystem.repositories.TicketRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
public class TicketService {

    @Autowired
    private TicketRepository ticketRepository;
    @Autowired
    private AttachmentsService attachmentService;
    @Autowired
    private CloudinaryService cloudinaryService;

    public Optional<Tickets> getTicketById(String ticketId) {
        return ticketRepository.findById(ticketId);
    }

    public Tickets createTicket(Tickets ticket)  {
//        System.out.println("i am here in service");
//        String fileUrl = cloudinaryService.uploadFile(file);
//        System.out.println(fileUrl);
//
//        Attachments attachment = new Attachments();
//        attachment.setTicketId(ticket);
//        attachment.setFilePath(fileUrl);
//        attachment.setTypeOfFile(file.getContentType());
//        attachment.setFileName(file.getOriginalFilename());
//
//        Attachments savedAttachment = attachmentService.saveAttachment(attachment);
//        System.out.println(savedAttachment.getTicketId());



        return ticketRepository.save(ticket);
    }

    public List<Tickets> getTicketsByCreatedBy(String createdBy) {
        return ticketRepository.findByCreatedBy(createdBy);
    }

    public List<Tickets> getTicketsByAssignTo(String assignTo) {
        return ticketRepository.findByAssignTo(assignTo);
    }

    public Optional<Tickets> updateTicket(String ticketId, Tickets updatedTicket) {
        return ticketRepository.findById(ticketId).map(existingTicket -> {
            existingTicket.setTitle(updatedTicket.getTitle());
            existingTicket.setDescription(updatedTicket.getDescription());
            existingTicket.setDepartment(updatedTicket.getDepartment());
            existingTicket.setAssignTo(updatedTicket.getAssignTo());
            existingTicket.setPriority(updatedTicket.getPriority());
            existingTicket.setDueDate(updatedTicket.getDueDate());
            existingTicket.setUpdatedBy(updatedTicket.getUpdatedBy());
            return ticketRepository.save(existingTicket);
        });
    }

    public Tickets findByTicketId(String ticketId) {
        return ticketRepository.findByTicketId(ticketId)
                .orElseThrow(() -> new IllegalArgumentException("Ticket not found with ID: " + ticketId));
    }

    // Combined search (optional filters)
    public List<Tickets> searchTickets(String createdBy, String assignTo) {
        return ticketRepository.findByCreatedByOrAssignTo(createdBy, assignTo);
    }
}
